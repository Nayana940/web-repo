text="Hello All"
print("Uppercase:",text.upper())
print("Lowercase:",text.lower())
print("Length of the text",len(text))
print("Replacing 'H' with 'S'",text.replace('H','S'))
print("First 5 characters:",text[:5])
