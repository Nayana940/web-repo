def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return(n*factorial(n-1))
def nPr(n,r):
    return(factorial(n)/factorial(n-r))

n = int(input("Enter n: "))
r = int(input("Enter r: "))
result=nPr(n,r) 
print("npr:",result)
