n=int(input("Enter the side of a square: "))
print("Area of square: ",n*n)
print("Perimeter of square: ",4*n)
