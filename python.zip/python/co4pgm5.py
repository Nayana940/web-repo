class Publisher:
	def __init__(self, name):
		self.name = name

class Book(Publisher):
	def __init__(self, name, title, author):
		super().__init__(name) 
		self.title = title
		self.author = author

	def display_info(self):
		print("Publisher:", self.name)
		print("Title:", self.title)
		print("Author:", self.author)

class Python(Book):
	def __init__(self, name, title, author, price, no_of_pages):
		super().__init__(name, title, author) 
		self.price = price
		self.no_of_pages = no_of_pages

	def display_info(self): 
		super().display_info() 
		print("Price:", self.price)
		print("Number of Pages:", self.no_of_pages)

name=input("Enter Publisher:")
title=input("Enter title:")
author=input("Enter author:")
price=int(input("Enter price:"))
no_of_pages=int(input("Enter number of pages:"))		
python_book = Python(name,title,author,price,no_of_pages)
python_book.display_info()
"""
mits@mits-HP-280-Pro-G6-Microtower-PC:~/Desktop/pooja$ python3 co4pgm5.py
Enter Publisher:Penquin books
Enter title:House of cards  
Enter author:Sudha Murty
Enter price:200
Enter number of pages:195
Publisher: Penquin books
Title: House of cards
Author: Sudha Murty
Price: 200
Number of Pages: 195
"""
