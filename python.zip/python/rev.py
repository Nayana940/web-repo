num=int(input("Enter the number:"))
s=0
r=0
n=num
while(n>0):
  d=n%10
  s=int(s+d)
  n=n/10;
while(num>0):
  d=num%10
  r=(r*10)+d
  num=num//10
print(s)
print(r)

