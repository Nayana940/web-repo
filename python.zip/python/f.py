n=int(input("Enter the range:"))
f1=0
f2=1
i=0
print(f1)
print(f2)
while(i<=n):
    f3=f1+f2
    print(f3)
    f1=f2
    f2=f3
    i=i+1
   
