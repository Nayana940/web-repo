class Rectangle:
	def __init__(self,length,breadth):
		self.length=length
		self.breadth=breadth
	def area(self):
		return self.length*self.breadth
	def perimeter(self):
		return 2*(self.length+self.breadth)
	def compare(self, otherrectangle):
		if self.area()>otherrectangle.area():
			return "The first rectangle has a larger area."
		elif self.area()<otherrectangle.area():
			return "The second rectangle has a larger area."
		else:
			return "Both rectangles have the same area."
	
x=int(input("Enter length"))
y=int(input("Enter breadth"))
rectangle1 = Rectangle(x, y)
print("Area of rectangle1:",rectangle1.area())
print("Perimeter of rectangle2:",rectangle1.perimeter())
rectangle2 = Rectangle(x, y)
print("Area of rectangle2:",rectangle1.area())
print("Perimeter of rectangle2:",rectangle1.perimeter())
z = rectangle1.compare(rectangle2)
print(z)
"""
output
its@mits-HP-280-Pro-G6-Microtower-PC:~/Desktop/pooja$ python3 co4pgm1.py
Enter length3
Enter breadth4
Area of rectangle1: 12
Perimeter of rectangle2: 14
Area of rectangle2: 12
Perimeter of rectangle2: 14
Both rectangles have the same area.
"""
