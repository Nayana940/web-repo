d={"name":"reja","age":30,"rollno":101}
print(d)
asc=dict(sorted(d.items()))
print("Ascending order: ",asc)
