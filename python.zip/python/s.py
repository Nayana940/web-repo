# Write a program to find the sum of elements in a list of numbers??
l=[]
n=int(input("Enter the numbers of elements in the list:"))
for i in range(1,n+1):
      num=int(input("Enter the elements:"))
      l.append(num)
print(l)
s=sum(l)
print("sum of the elements in the list",s)
     
