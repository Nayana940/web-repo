with open("name.txt","r") as f:
 nlist=f.readlines()
print("The names are: ")
print(nlist)
nlist=[x.split() for x in nlist]
print("The names are: ")
print(nlist)
