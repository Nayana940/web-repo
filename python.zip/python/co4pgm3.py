#Create a class Rectangle with private attributes length and width. Overload ‘<’ operator to compare the area of 2 rectangle
class Rectangle:
	def __init__(self, length, width):
		self._length = length 
		self._width = width 
	def area(self):
		return self._length * self._width
	def __lt__(self, other):
		return self.area()>other.area()

x=int(input("Enter length of rectangle1:"))
y=int(input("Enter width of rectangle1:"))
m=int(input("Enter length of rectangle2:"))
n=int(input("Enter width of rectangle2:"))
rectangle1 = Rectangle(x,y)
rectangle2 = Rectangle(m,n)
if rectangle1<rectangle2:
	print("Area of Rectangle 1 is smaller than the area of Rectangle 2.")
elif rectangle1>rectangle2:
	print("Area of Rectangle 1 is larger than the area of Rectangle 2.")
else:
	print("Both rectangles have the same area.")

"""
mits@mits-HP-280-Pro-G6-Microtower-PC:~/Desktop/pooja$ python3 co4pgm3.py
Enter length of rectangle1:3
Enter width of rectangle1:4
Enter length of rectangle2:7
Enter width of rectangle2:5
Area of Rectangle 1 is larger than the area of Rectangle 2.
"""

