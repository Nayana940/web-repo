text=input("Enter a line of text:")
print("The number of characters=",len(text))
if len(text)>=2:
  print("The second character is:",text[1])
