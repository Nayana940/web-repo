word='BANANA'
for letter in word:
  print(letter)
