name=input("Enter your name:")
print("WELCOME",name,"to MITS....")
