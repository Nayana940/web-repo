item=input("Enter a list of items").split()
unique=list(set(item))
print("List after removing duplicates",unique)
