numbers=[int(input("Enter the number"))for i in range(4)]
smallest=min(numbers)
print("The smallest is ",smallest)
