#2 Create a list of numbers to perfirm the following operation
#smallest number
#Largest
#remove duplicate#append a list of numbers to the existing list
l=[]
n=int(input("Enter n:"))
for i in range(1,n+1):
    num=int(input("Enter the elements:"))
    l.append(num)
print(l)
l1=[]
[l1.append(x) for x in l if x not in l1]
print("remove duplicates",l1)
small=min(l)
largest=max(l)
print("smallest number in the list is ",small)
print("Largest number in the list is",largest)
newl=[]
n=int(input("Enter n:"))
for i in range(1,n+1):
    num=int(input("Enter the elements:"))
    l.append(num)
print("New List",newl)
l=l+newl
print(l)

