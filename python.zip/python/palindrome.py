str=input("Enter the string:")
print("Check whether the string is palindrome or not")

if(str==str[::-1]):
  print("The string is palidrome")
else:
  print("The string is not palidrome")


