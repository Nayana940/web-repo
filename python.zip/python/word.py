text=input("Enter the text:")
words=input("Enter the word to check:")
if words in text:
         print(words,"is present")
else:
         print(words,"is not present")
