class BankAccount:
	def __init__(self, account_number, account_holder_name, account_type, balance):
		self.account_number = account_number
		self.account_holder_name = account_holder_name
		self.account_type = account_type
		self.balance = balance
	def deposit(self, amount):
		if amount>0:
			self.balance += amount
			print("Deposit successful of ", amount)
			print("New balace=",self.balance)
		else:
			print("Invalid deposit amount.")
	def withdraw(self, amount):
		if 0<amount<self.balance:
			self.balance=self.balance-amount
		elif amount>self.balance:
			print("Not possible to withdraw")
		else:
			print("invalid")
	def getbalance(self):
		print("Current balance=",self.balance)

ano=int(input("Enter account number:"))
name=input("Enter account holder:")
atype=input("Enter account type:")
amt=int(input("Enter account initial balance:"))
account1=BankAccount(ano,name,atype,amt)
account1.getbalance()
ch=0
while(ch!=4):
	print("\n\n1.Deposit amount\n2.Withdraw amount\n3.See account balance\n4.Exit");
	ch=int(input("Enter choice"))
	if ch==1:
		damount=int(input("Enter the amount to be deposited:"))
		account1.deposit(damount)
	elif ch==2:
		wamount=int(input("Enter the amount to be withdrawn:"))
		account1.withdraw(wamount)
		account1.getbalance()
	elif ch==3:
		account1.getbalance()
	else:
		print("Invalid");
"""
mits@mits-HP-280-Pro-G6-Microtower-PC:~/Desktop/pooja$ python3 co4pgm2.py
Enter account number:123
Enter account holder:Diana
Enter account type:savings
Enter account initial balance:1000
Current balance= 1000


1.Deposit amount
2.Withdraw amount
3.See account balance
4.Exit
Enter choice1
Enter the amount to be deposited:2000
Deposit successful of  2000
New balace= 3000


1.Deposit amount
2.Withdraw amount
3.See account balance
4.Exit
Enter choice2
Enter the amount to be withdrawn:1999
Current balance= 1001


1.Deposit amount
2.Withdraw amount
3.See account balance
4.Exit
Enter choice3
Current balance= 1001


1.Deposit amount
2.Withdraw amount
3.See account balance
4.Exit
Enter choice4
Invalid

"""
