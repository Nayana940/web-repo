##Write a program to read a file line by line and store it in the list???

with open("stud.txt") as f:
    slist=f.readlines()
print("\nContents of file with new line are :")
print(slist)

slist=[x.strip() for x in slist]
print("\nContents of file without new line are :")
print(slist)
