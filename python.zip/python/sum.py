num1=float(input("Enter the first floating point number:"))
num2=float(input("Enter the second floating point number:"))
total=num1+num2
print("sum of",num1,"and",num2,"is",total)
