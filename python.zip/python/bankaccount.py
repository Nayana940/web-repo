class BankAccount:
	def __init__(self, account_number, account_holder_name, account_type, balance):
		self.account_number = account_number
		self.account_holder_name = account_holder_name
		self.account_type = account_type
		self.balance = balance
	def deposit(self,amount):
		if amount>0:
			self.balance += amount
			print("Deposit successful of ", amount)
			print("New balace=",self.balance)
		else:
			print("Invalid deposit amount.")
	def withdraw(self,amount):
		if 0<amount<self.balance:
			self.balance=self.balance-amount
		elif amount>self.balance:
			print("Not possible to withdraw")
		else:
			print("invalid")
	def getbalance(self):
		print("Current balance=",self.balance)


ano=int(input("Enter the account number:"))
name=input("Enter the accountholder name:")
atype=input("Enter the accounttype")
amt=int(input("Enter the balance amount:"))
account1=BankAccount(ano,name,atype,amt)
account1.getbalance()
ch=0
while(ch!=4):
        print("\n\n1.Deposit amount\n2.Withdraw amount\n3.See account balance\n4.Exit");
        ch=int(input("Enter choice"))
          if ch==1:
             damount=int(input("Enter the amount to be deposited:"))
             account1.deposit(damount)
          elif ch==2:
             wamount=int(input("Enter the amount to be withdrawn:"))
             account1.withdraw(wamount)
             account1.getbalance()
         elif ch==3:
            account1.getbalance()
         else:
            print("Invalid");









account1.getbalance()
















damount=int(input("Enter the amount to be deposited"))
account1.deposit(damount)
wamount=int(input("Enter the amount to be withdrawn"))
account1.withdraw(wamount)
account1.getbalance()
 
