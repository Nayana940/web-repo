#input a string and perform the following operation
#LIST OF THE STRING 
#REVERSE
##REPLCAE WITH $
string=input("Enter the string:")
length=len(string)
print("Length of the string is:",length)
sr=string[::-1]
print("REVERSE OF THE STRING",sr)
sr=string[0]+string[1:].replace(string[0],'$')
print("REPLACE",sr)

