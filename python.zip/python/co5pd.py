import pandas as pd
d={'name': ['pooja','Anu','Anila'],'age':[22,23,21]}
print(d)
var = pd.DataFrame(d)

print(var)
