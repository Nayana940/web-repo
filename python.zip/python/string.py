string=input("Enter a string:")
print("reverse of the string:",string[::-1])
