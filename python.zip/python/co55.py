import csv
field=['rno','name','age']
sdict=[{'rno':6,'name':'riya','age':28},
{'rno':7,'name':'Sitha','age':27}]
with open("dept.csv",'w')as dfile:
    writer=csv.DictWriter(dfile,fieldnames=field)
    writer.writeheader()
    writer.writerows(sdict)
